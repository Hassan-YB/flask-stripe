/**
 * @file A simple JSON viewer and editor
 * @author yuhui06
 * @date 2018/5/25
 */

require('static/css/jquery.json-viewer.css');

__inline('static/js/jquery.json-viewer.js');
__inline('static/js/jquery.json-editor.js');